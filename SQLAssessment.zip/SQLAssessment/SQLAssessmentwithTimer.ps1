﻿ 
 $StartTime = get-date 
 write-host "the script started at" $StartTime
 #Get-AzDataMigrationPerformanceDataCollection -SqlConnectionStrings "Data Source=fuzionssis01-dev;Integrated Security=True" -OutputFolder "C:\SQLAssessment\PerformanceData\Output" -Time 600

 Get-AzDataMigrationPerformanceDataCollection -ConfigFilePath "C:\SQLAssessment\PerformanceData\Prod\config01.json" 
   
 $RunTime = New-TimeSpan -Start $StartTime -End (get-date) 
 "Execution time was {0} hours, {1} minutes, {2} seconds and {3} milliseconds." -f $RunTime.Hours,  $RunTime.Minutes,  $RunTime.Seconds,  $RunTime.Milliseconds 
 
