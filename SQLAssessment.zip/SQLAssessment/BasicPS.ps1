﻿Install-Module dbatools

Import-Module dbatools 

Set-ExecutionPolicy RemoteSigned 

$ProdSql = Get-dbaRegServer -Group Prod 

$DevSql = Get-dbaRegServer -Group Dev

$Sqlinstances = $ProdSql.ServerName 
$SqlinstancesDev= $DevSql.ServerName 

$Sqlinstances

$SqlinstancesDev