---DMA 
SELECT name, '"C:\Program Files\Microsoft Data Migration Assistant\DmaCmd.exe" ' + 
    '/AssessmentName="DMA_Output" ' +
    '/AssessmentDatabases="Server=' + @@ServerName +
    ';Initial Catalog=' + sys.databases.name +
    ';Integrated Security=true" ' + 
    '/AssessmentEvaluateCompatibilityIssues /AssessmentOverwriteResult ' + 
    '/AssessmentResultCSV="\\PathToSaveTo\'+REPLACE(@@ServerName,'\','_')+'\'+sys.databases.name+'.CSV"' +
    ' > "\\PathToSaveTo\'+REPLACE(@@ServerName,'\','_')+'\'+sys.databases.name+'.LOG"'
FROM sys.databases WHERE state <> 6 -- exclude offline databases
  and database_id > 4 -- Exclude system databases

  ---Collect PerfCollections data

  Example 

 --.\SqlAssessment.exe PerfDataCollection 
--sqlConnectionStrings "Data Source=Server1;Initial Catalog=master;Integrated Security=True;" "Data Source=Server2;Initial Catalog=master;Integrated Security=True;" 
--outputFolder C:\Output

select '\SqlAssessment.exe PerfDataCollection'+
'  --sqlConnectionStrings "Data Source='+@@SERVERNAME+';Initial Catalog=master;Integrated Security=True;'

\SqlAssessment.exe PerfDataCollection  --sqlConnectionStrings "Data Source=FUZIONSSIS01-DE;Initial Catalog=master;Integrated Security=True;

--Json file 

{
  "action": "PerfDataCollection",
  "sqlConnectionStrings": [
  "Data Source=fuzionsql02-dev;Initial Catalog=master;Integrated Security=True;",
  "Data Source=fuzionssis01-dev;Initial Catalog=master;Integrated Security=True;"
  ],
  "numberOfIterations": "40",
  "outputFolder": "C:\\SQLAssessment\\PerformanceData\\cmd"
}

.\SqlAssessment.exe --configFile C:\SQLAssessment\PerformanceData\cmd\config.json

{
  "action": "PerfDataCollection",
  "sqlConnectionStrings": [
  "Data Source=fuzionsql03;Initial Catalog=master;Integrated Security=True;",
  "Data Source=fuzionsql02;Initial Catalog=master;Integrated Security=True;",
  "Data Source=SSIS01-P;Initial Catalog=master;Integrated Security=True;"
  ],
  "numberOfIterations": "600",
  "outputFolder": "C:\\SQLAssessment\\PerformanceData\\cmd"
}