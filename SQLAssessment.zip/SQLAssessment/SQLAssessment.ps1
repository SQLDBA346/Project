﻿ Install-Module -Name Az.DataMigration -RequiredVersion 0.12.0

 Update-Module -Name Az.DataMigration -RequiredVersion 0.12.0 -Force

 Get-Module -Name Az.DataMigration

 Get-InstalledModule -Name Az.DataMigration | Uninstall-Module

  $StartTime = get-date 
  
 Get-AzDataMigrationPerformanceDataCollection -SqlConnectionStrings "Data Source=fuzionssis01-dev;Integrated Security=True" - -OutputFolder "C:\SQLAssessment\PerformanceData\dev" -PassThru 



 #Get-AzDataMigrationSkuRecommendation -OutputFolder "C:\SQLAssessment\PerformanceData\Prod" -DisplayResult -Overwrite
 
  $RunTime = New-TimeSpan -Start $StartTime -End (get-date) 
 write-host "Execution time was {0} hours, {1} minutes, {2} seconds and {3} milliseconds." -f $RunTime.Hours,  $RunTime.Minutes,  $RunTime.Seconds,  $RunTime.Milliseconds 
 