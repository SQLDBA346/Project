﻿

#function Get-sqlinfo {
    [CmdletBinding()]
    param(
        [Parameter (Mandatory=$True,
                    ValueFromPipeline = $True,
                    ValueFromPipelineByPropertyName = $True,
                    HelpMessage="The. Computer. Name. Please")]
        [Alias('Hostname','cn')]
        [String[]]$ComputerName )

    Begin {
            
            $filePath = "C:\SQLAssessment\SqlInstance"
            $Date = Get-Date -format MMddyyyy
 
    }
    Process {
           Write-Host "------------------------------------------------------"
           Write-host "Retrieving SQL instance information from $ComputerName"

           foreach($computer in $ComputerName) {
           try {
                        Write-Host "Computer : $computer"       
                        $sql = Find-DbaInstance -ComputerName $computer -ErrorAction Inquire
                        #write-host " Value of"
                        #$sql 
                        if ($null -eq $sql) {
                           throw "NOt able to connect $computer"
                        } 
                         elseif ($null -ne $sql) {
                         write-host 'here'
                         $sqlinventory= new-object -TypeName PSObject -Property $properties
                                  $properties = @{
                                    ComputerName = $computer
                                    Status = 'Connnected'
                                    SQLInstance = $sql.SqlInstance
                                    Filepath= 'C:\SQLAssessment\SqlInstance'
                                    Port =$sql.Port
                                                  }  
             
                            $SqlInstances = $properties.SqlInstance
                            
                            $SqlInstances

                            foreach ($SqlInstance in $SqlInstances) {

                                    If ($SqlInstance.Contains('\')) {

                                        $sqlname= $Sqlinstance.Replace('\','_')
                                    } else {
                                        $sqlname= $SqlInstance
                                    }

                                $FileName = "Inventory_" + $sqlname+ "_"+ $Date + ".txt"
                               #$FileName = "Inventory_"+ $Date + ".txt"

                                $xlfile = "$FilePath\$FileName"
                                $properties.Filepath += "\" + $FileName

                                $properties.Filepath

                                Remove-Item $xlfile -ErrorAction SilentlyContinue
                            #Computer 
                            write-output "------------------------------------------" | out-file $xlfile -Append
                            Write-output "#1# To connect to an SQL Server $SqlInstance ##" | out-file $xlfile -Append


                            $TestConnections =Test-DbaConnection -SqlInstance $SqlInstance | select ComputerName,SqlInstance,ConnectingAsUser,AuthScheme,IPAddress,TcpPort,DomainName,PSRemotingAccessible

                            $TestConnections | out-file $xlfile -Append


                            Write-output "#2# Computer System information ##" | out-file $xlfile -Append


                            $Systeminfo = Get-DbaComputerSystem -ComputerName $ComputerName

                            $Systeminfo | out-file $xlfile -Append

                            Write-output "#3# SQL server uptime  ##" | out-file $xlfile -Append

                            Get-DbaUptime -SqlInstance $SqlInstance | out-file $xlfile -Append

                            ## Get Build reference 


                            Write-output "#4# SQL instance Build information ##" | out-file $xlfile -Append

                            Get-DbaBuildReference -SqlInstance $SqlInstance | out-file $xlfile -Append


                            #Finding the service account of a SQL Server instance

                            Write-output "#5# Service accounts information ##" | out-file $xlfile -Append

                            #Get-DbaService -ComputerName $ComputerName -Type Engine,Agent,SSIS,SSAS,SSRS | Select-Object ComputerName, InstanceName,ServiceName, StartName, State, StartMode | ft | out-file $xlfile -Append





                            Write-output "#6# SQL Instance Max Memory value ##" | out-file $xlfile -Append

                            $SQLMaxMemory = Test-DbaMaxMemory -sqlinstance $SqlInstance


                            #Write-Output  "The maximum memory configured on SQL Server is $($SQLMaxMemory.MaxValue) mb on $($SQLMaxMemory.SqlInstance) SqlInstance `r`n and Recommended Value is $($SQLMaxMemory.RecommendedValue) mb. " | out-file $xlfile -Append

                            $SQLMaxMemory | out-file $xlfile -Append

                            ## MAXDOP 
                            Write-output "#7# MaxDOP value ##" | out-file $xlfile -Append

                            $MaxDop = Test-DbaMaxDop -SqlInstance $Sqlinstance

                            Write-Output  "The MaxDop is set to $($MaxDop.CurrentInstanceMaxDop) on $($SQLMaxMemory.SqlInstance) SqlInstance and Recommended MaxDop value is $($MaxDop.RecommendedMaxDop)." | out-file $xlfile -Append

                            $MaxDop| out-file $xlfile -Append



                            #dbs
                            Write-output "#8# List of System and User DBs ##" | out-file $xlfile -Append

                            $DBs = Get-DbaDatabase -SqlInstance $SqlInstance 

                            $DBs | select SqlInstance,Name, Status, IsAccessible, RecoveryModel, SizeMB | ft -GroupBy Sqlinstance | out-file $xlfile -Append

                            $DBproperties = $DBs | Where-Object  {$_.database -cnotin ('master','tempdb','msdb','model')} |Select-Object SqlInstance, Name,PageVerify,AutoupdateStatisticsEnabled,SnapshotIsolationState, IsDatabaseSnapshot,IsDatabaseSnapshotBase,IsReadCommittedSnapshotOn 

                            Write-output "#9# User DBs Properties ##" | out-file $xlfile -Append

                            $DBproperties | ft -GroupBy Sqlinstance | out-file $xlfile -Append


                             #checks for Enterprise feature usage.
                            Write-output "#10# Checks for Enterprise feature usage ##" | out-file $xlfile -Append

                            Get-DbaDbFeatureUsage -SqlInstance $sqlinstance | out-file $xlfile -Append


                            #Last check db and backup 
                            Write-output "#11# Last full backup user database information ##" | out-file $xlfile -Append

                            #Get-DbaDbBackupHistory -SqlInstance $sqlinstance | ft -GroupBy Database

                             $userdbbackupinfo = Get-DbaDbBackupHistory -SqlInstance $sqlinstance -Type Full -Since (Get-Date).Adddays(-8) -ExcludeDatabase master,model,msdb |`
                             Select-Object SQLInstance,Database,Start,@{n='TotalSizeMB';e={$_.TotalSize.MegaByte}},@{n='CompressedBackupSizeMB';e={$_.CompressedBackupSize.MegaByte}}|`
                             Sort-Object -Property SQLInstance,Database,Start  | ft -GroupBy Database ;

                             $userdbbackupinfo | out-file $xlfile -Append 


                             # Last good check db 

                            $DBCCCheckdb= $DBs | Where-Object  {$_.Name -cnotin 'tempdb'} | Get-DbaLastGoodCheckDb | Select-Object SqlInstance, Database,LastGoodCheckDb,DaysSinceLastGoodCheckDb,Status | Ft -GroupBy Sqlinstance -AutoSize

                            Write-output "#12# Last known good DBCC CHECKDB##" | out-file $xlfile -Append

                            $DBCCCheckdb | out-file $xlfile -Append 


                             #Diskspace

                             #Get-command *Diskspace*

                             #Get-DbaDiskSpace -ComputerName $ComputerName -unit GB

                             Write-output "#13# Disk Space information##" | out-file $xlfile -Append

                              $Diskspace = Get-DbaDiskSpace -ComputerName $ComputerName -unit GB
  
                              $Diskspace | Format-Table ComputerName, Name , Lable ,Capacity , Free, PercentFree, BlockSize  -GroupBy ComputerName | out-file $xlfile -Append

  
                            #db growth
                            Write-output "#14# DB files Growth information##" | out-file $xlfile -Append

                            #Get-command "*Growth*"
                            Get-DbaDbFileGrowth -SqlInstance $SqlInstance | select SqlInstance,Database,MaxSize,GrowthType, Growth, File, FileName,State | ft -AutoSize -GroupBy SQLinstance | out-file $xlfile -Append

                            Get-DbaDbFileGrowth -SqlInstance $SqlInstance |Where-Object  {$_.database -cnotin ('master','tempdb','msdb','model')} | select SqlInstance,Database,MaxSize,GrowthType, Growth, File, FileName,State | ft -AutoSize -GroupBy SQLinstance 

                            Write-output "#15# All DBs files information##" | out-file $xlfile -Append

                            Get-DbaDbFile -SqlInstance $SqlInstance |select SqlInstance,Database, DatabaseID, FileGroupName, LogicalName, PhysicalName,State,Maxsize, Growth, GrowthType | Format-Table -GroupBy SqlInstance | out-file $xlfile -Append

                             #Tempdb 

                             Write-output "#16# Tempdb Recommandations##" | out-file $xlfile -Append
                              #get-command *tempdb*

                              #Get-DbaTempdbUsage -SqlInstance $SqlInstance

                              #Test-DbaTempDbConfig -SqlInstance $SqlInstance | select SqlInstance, Rule, Recommended, CurrentSetting, IsBestpractice, Notes | ft -AutoSize 

                              Test-DbaTempDbConfig -SqlInstance $SqlInstance | select SqlInstance, Rule, Recommended, CurrentSetting, IsBestpractice, Notes | ft -AutoSize -GroupBy SQLinstance | out-file $xlfile -Append
  
                              Write-output "#17# Tempdb files information##" | out-file $xlfile -Append

                              Get-DbaDbFile -SqlInstance $SqlInstance  -Database tempdb |select SqlInstance,Database, DatabaseID, FileGroupName, LogicalName, PhysicalName,State,Maxsize, Growth, GrowthType | ft -AutoSize -GroupBy SQLinstance | out-file $xlfile -Append


                            #File stats in sys.dm_io_virtual_file_stats
                            #   #https://learn.microsoft.com/en-us/troubleshoot/sql/performance/troubleshoot-sql-io-performance

                            Write-output "#18# IO Statistics Report ##" | out-file $xlfile -Append

                            $query =  "SELECT   LEFT(mf.physical_name,100) as PhyiscalFile_location,   `
                                     [ReadLatency(ms)] = CASE WHEN num_of_reads = 0 THEN 0 ELSE (io_stall_read_ms / num_of_reads) END, `
                                     [WriteLatency(ms)] = CASE WHEN num_of_writes = 0 THEN 0 ELSE (io_stall_write_ms / num_of_writes) END, `
                                     [AvgLatency(% Total IO)] =  CASE WHEN (num_of_reads = 0 AND num_of_writes = 0) THEN 0 `
                                                    ELSE (io_stall / (num_of_reads + num_of_writes)) END,`
                                     LatencyAssessment = CASE WHEN (num_of_reads = 0 AND num_of_writes = 0) THEN 'No data' ELSE `
                                           CASE WHEN (io_stall / (num_of_reads + num_of_writes)) < 2 THEN 'Excellent' `
                                                WHEN (io_stall / (num_of_reads + num_of_writes)) BETWEEN 2 AND 5 THEN 'Very good' `
                                                WHEN (io_stall / (num_of_reads + num_of_writes)) BETWEEN 6 AND 15 THEN 'Good' `
                                                WHEN (io_stall / (num_of_reads + num_of_writes)) BETWEEN 16 AND 100 THEN 'Poor' `
                                                WHEN (io_stall / (num_of_reads + num_of_writes)) BETWEEN 100 AND 500 THEN  'Bad' `
                                                ELSE 'Deplorable' END  END, `
                                     [Avg KBs/Transfer] =  CASE WHEN (num_of_reads = 0 AND num_of_writes = 0) THEN 0 `
                                                ELSE ((([num_of_bytes_read] + [num_of_bytes_written]) / (num_of_reads + num_of_writes)) / 1024) END, `
                                     LEFT (mf.physical_name, 2) AS Volume, `
                                     LEFT(DB_NAME (vfs.database_id),32) AS [Database Name]`
                                   FROM sys.dm_io_virtual_file_stats (NULL,NULL) AS vfs  `
                                   JOIN sys.master_files AS mf ON vfs.database_id = mf.database_id `
                                     AND vfs.file_id = mf.file_id `
                                   ORDER BY [AvgLatency(% Total IO)] DESC"
       
                                  $sqlio= Invoke-DbaQuery -SqlInstance $SqlInstance -Query $query 

                                  $sqlio | ft  | out-file $xlfile -width 999999 -Append


                            #install Blizt scripts 

                            Write-output "#19# Install Brent's FirstResponderKit to master database##" | out-file $xlfile -Append

                            #Install-DbaFirstResponderKit -SqlInstance $SqlInstance -Database master -Force

                            Write-output "#20# Installed Health check scripts to master database##" | out-file $xlfile -Append

                            #Execute sp_Blitz

                            Write-output "#20#Execute the sp_Blitz command with the @CheckServerInfo parameter to get extra information about server##" | out-file $xlfile -Append

                            $results = Invoke-DbaQuery -SqlInstance $SqlInstance -Database master -Query "EXEC sp_blitz @CheckServerInfo = 1"

                            $results | select Priority,FindingsGroup,Finding,DatabaseName,URL,Details | Ft | out-file $xlfile -width 999999 -Append

                            #Write-DbaDbTableData -SqlInstance $SqlInstance -Database master -InputObject $results -Table 'spBlitz_checksrvoutput'

                            #Write-host @properties

                           }
    
            }
   
          } catch {
                Write-Verbose "Couold not connect to $computer" 
                $properties = @{ComputerName = $computer
                                Status = 'Disconnnected'
                                SQLInstance = $null
                                Port =$null}
          }

          finally {
             $sqlinventory= new-object -TypeName PSObject -Property $properties  
                          Write-Output $sqlinventory | Format-List
          }
        }
    }
    End {}
#}